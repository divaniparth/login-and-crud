from django.shortcuts import render,redirect,HttpResponseRedirect,HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth import logout ,authenticate ,login
from . import views
from .models import Student

def index(request):
    if request.user.is_anonymous:        
        return redirect("/login")
    return render(request,'index.html')


def loginuser(request):
    if request.method =="POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username,password=password)
        if user is not None:
            login(request, user)
            return redirect('/index')
        else:
            msg="Check ID And Password"
            return render(request, 'login.html',{'msg':msg})
    return render(request, 'login.html')
    
def logoutuser(request):
    logout(request)
    return redirect("/login")

def send(request):
    if request.method =="POST":
        ID = request.POST['id']
        name = request.POST['name']
        email = request.POST['email']
        phone = request.POST['phone']
        city = request.POST['city']
        state = request.POST['state']
        zip = request.POST['zip']
        Student(ID=ID,name=name,email=email,phone=phone,city=city,state=state,zip=zip).save()
        msg="Data Stored Successfully"
        return render(request,"index.html",{'msg':msg})      
    else:
        return HttpResponse("<h1>404 - Not Found</h1>")
  
def show(request):
    
    data = Student.objects.all()
    return render(request,"show.html",{'data':data})


def delete(request):
    
   
    ID = request.GET['id']
    Student.objects.filter(ID=ID).delete()
    return HttpResponseRedirect("show")

def edit(request):
   
    ID = request.GET['id']
    name = email = phone = city = state = zip =  "Not Available"
    for data in Student.objects.filter(ID=ID):
        name = data.name
        email = data.email
        phone = data.phone
        city = data.city
        state = data.state
        zip = data.zip        
    return render(request,"edit.html",{'ID':ID,'name':name,'email':email,'phone':phone,'city':city,'state':state,'zip':zip})

def RecordEdited(request):
    
    if request.method == 'POST':
        ID = request.POST['id']
        name = request.POST['name']
        email = request.POST['email']
        phone = request.POST['phone']
        city = request.POST['city']
        state = request.POST['state']
        zip = request.POST['zip']
      
        Student.objects.filter(ID=ID).update(name=name,email=email,phone=phone,city=city,state=state,zip=zip)
        return HttpResponseRedirect("show")
    else:
        return HttpResponse("<h1>404 - Not Found</h1>")