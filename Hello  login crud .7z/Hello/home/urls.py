from django.urls import path
from . import views

urlpatterns = [


    path('', views.loginuser, name='login'),
    path('index', views.index, name='index'),
    path('send', views.send, name='send'),  
    path('show', views.show, name='show'),
    path('delete', views.delete, name='delete'),
    path('edit', views.edit, name='edit'),
    path('RecordEdited', views.RecordEdited, name='RecordEdited'),
    path('login', views.loginuser, name='login'),
    path('logout', views.logoutuser, name='logout'),
   




]
